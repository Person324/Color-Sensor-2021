# Read RGB Values

### Description
This example shows how to retrieve values from the REV Color Sensor V3.

### Usage
Change the I2C port at the beginning of the program to match the connection of your color sensor.

When ran, the red, green, blue, infrared, and proximity values from the Color Sensor will be displayed on SmartDashboard/Shuffleboard.