# Color Match

### Description
This example shows how the REV Color Sensor V3 can be used to detect various pre-configured colors.

### Usage
Change the I2C port at the beginning of the program to match the connection of your color sensor.

When ran, the RGB values, detected color, and confidence will be displayed on SmartDashboard/Shuffleboard.