# Color Match

### Description
This example shows how the REV Color Sensor V3 can be used to detect various pre-configured colors.